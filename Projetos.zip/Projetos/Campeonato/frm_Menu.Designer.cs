﻿namespace Campeonato
{
    partial class frm_Menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.atualizaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatorioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl_Atualiza = new System.Windows.Forms.Panel();
            this.btn_Encerra = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.btn_Atualiza = new System.Windows.Forms.Button();
            this.lbl_TimeB = new System.Windows.Forms.Label();
            this.txt_TimeB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_TimeA = new System.Windows.Forms.TextBox();
            this.lbl_TimeA = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_Relatorio = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Campeao = new System.Windows.Forms.Label();
            this.txt_Time06 = new System.Windows.Forms.TextBox();
            this.txt_Time05 = new System.Windows.Forms.TextBox();
            this.lbl_Time06 = new System.Windows.Forms.Label();
            this.lbl_Time05 = new System.Windows.Forms.Label();
            this.txt_Time04 = new System.Windows.Forms.TextBox();
            this.txt_Time03 = new System.Windows.Forms.TextBox();
            this.txt_Time02 = new System.Windows.Forms.TextBox();
            this.txt_Time01 = new System.Windows.Forms.TextBox();
            this.lbl_Time04 = new System.Windows.Forms.Label();
            this.lbl_Time03 = new System.Windows.Forms.Label();
            this.lbl_Time02 = new System.Windows.Forms.Label();
            this.lbl_Time01 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.pnl_Atualiza.SuspendLayout();
            this.pnl_Relatorio.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.atualizaçãoToolStripMenuItem,
            this.relatorioToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // atualizaçãoToolStripMenuItem
            // 
            this.atualizaçãoToolStripMenuItem.Name = "atualizaçãoToolStripMenuItem";
            this.atualizaçãoToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.atualizaçãoToolStripMenuItem.Text = "Atualização";
            this.atualizaçãoToolStripMenuItem.Click += new System.EventHandler(this.AtualizaçãoToolStripMenuItem_Click_1);
            // 
            // relatorioToolStripMenuItem
            // 
            this.relatorioToolStripMenuItem.Name = "relatorioToolStripMenuItem";
            this.relatorioToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.relatorioToolStripMenuItem.Text = "Relatorio";
            this.relatorioToolStripMenuItem.Click += new System.EventHandler(this.RelatorioToolStripMenuItem_Click);
            // 
            // pnl_Atualiza
            // 
            this.pnl_Atualiza.Controls.Add(this.btn_Encerra);
            this.pnl_Atualiza.Controls.Add(this.btn_Proximo);
            this.pnl_Atualiza.Controls.Add(this.btn_Atualiza);
            this.pnl_Atualiza.Controls.Add(this.lbl_TimeB);
            this.pnl_Atualiza.Controls.Add(this.txt_TimeB);
            this.pnl_Atualiza.Controls.Add(this.label2);
            this.pnl_Atualiza.Controls.Add(this.txt_TimeA);
            this.pnl_Atualiza.Controls.Add(this.lbl_TimeA);
            this.pnl_Atualiza.Controls.Add(this.label1);
            this.pnl_Atualiza.Location = new System.Drawing.Point(22, 63);
            this.pnl_Atualiza.Name = "pnl_Atualiza";
            this.pnl_Atualiza.Size = new System.Drawing.Size(757, 324);
            this.pnl_Atualiza.TabIndex = 1;
            this.pnl_Atualiza.Visible = false;
            // 
            // btn_Encerra
            // 
            this.btn_Encerra.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Encerra.Location = new System.Drawing.Point(615, 146);
            this.btn_Encerra.Name = "btn_Encerra";
            this.btn_Encerra.Size = new System.Drawing.Size(75, 23);
            this.btn_Encerra.TabIndex = 8;
            this.btn_Encerra.Text = "Encerrar";
            this.btn_Encerra.UseVisualStyleBackColor = true;
            this.btn_Encerra.Click += new System.EventHandler(this.Btn_Encerra_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Proximo.Location = new System.Drawing.Point(534, 146);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(75, 23);
            this.btn_Proximo.TabIndex = 7;
            this.btn_Proximo.Text = "Proximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.Btn_Proximo_Click);
            // 
            // btn_Atualiza
            // 
            this.btn_Atualiza.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Atualiza.Location = new System.Drawing.Point(453, 146);
            this.btn_Atualiza.Name = "btn_Atualiza";
            this.btn_Atualiza.Size = new System.Drawing.Size(75, 23);
            this.btn_Atualiza.TabIndex = 6;
            this.btn_Atualiza.Text = "Atualiza";
            this.btn_Atualiza.UseVisualStyleBackColor = true;
            this.btn_Atualiza.Click += new System.EventHandler(this.Btn_Atualiza_Click);
            // 
            // lbl_TimeB
            // 
            this.lbl_TimeB.AutoSize = true;
            this.lbl_TimeB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TimeB.Location = new System.Drawing.Point(334, 54);
            this.lbl_TimeB.Name = "lbl_TimeB";
            this.lbl_TimeB.Size = new System.Drawing.Size(52, 16);
            this.lbl_TimeB.TabIndex = 5;
            this.lbl_TimeB.Text = "Time_B";
            // 
            // txt_TimeB
            // 
            this.txt_TimeB.Location = new System.Drawing.Point(286, 52);
            this.txt_TimeB.Name = "txt_TimeB";
            this.txt_TimeB.Size = new System.Drawing.Size(36, 20);
            this.txt_TimeB.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(265, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "X";
            // 
            // txt_TimeA
            // 
            this.txt_TimeA.Location = new System.Drawing.Point(223, 52);
            this.txt_TimeA.Name = "txt_TimeA";
            this.txt_TimeA.Size = new System.Drawing.Size(36, 20);
            this.txt_TimeA.TabIndex = 2;
            // 
            // lbl_TimeA
            // 
            this.lbl_TimeA.AutoSize = true;
            this.lbl_TimeA.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TimeA.Location = new System.Drawing.Point(128, 56);
            this.lbl_TimeA.Name = "lbl_TimeA";
            this.lbl_TimeA.Size = new System.Drawing.Size(52, 16);
            this.lbl_TimeA.TabIndex = 1;
            this.lbl_TimeA.Text = "Time_A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(280, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Jogo 001";
            // 
            // pnl_Relatorio
            // 
            this.pnl_Relatorio.Controls.Add(this.label3);
            this.pnl_Relatorio.Controls.Add(this.lbl_Campeao);
            this.pnl_Relatorio.Controls.Add(this.txt_Time06);
            this.pnl_Relatorio.Controls.Add(this.txt_Time05);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time06);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time05);
            this.pnl_Relatorio.Controls.Add(this.txt_Time04);
            this.pnl_Relatorio.Controls.Add(this.txt_Time03);
            this.pnl_Relatorio.Controls.Add(this.txt_Time02);
            this.pnl_Relatorio.Controls.Add(this.txt_Time01);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time04);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time03);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time02);
            this.pnl_Relatorio.Controls.Add(this.lbl_Time01);
            this.pnl_Relatorio.Location = new System.Drawing.Point(25, 61);
            this.pnl_Relatorio.Name = "pnl_Relatorio";
            this.pnl_Relatorio.Size = new System.Drawing.Size(751, 329);
            this.pnl_Relatorio.TabIndex = 2;
            this.pnl_Relatorio.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(433, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "Time Campeão";
            // 
            // lbl_Campeao
            // 
            this.lbl_Campeao.AutoSize = true;
            this.lbl_Campeao.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Campeao.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Campeao.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Campeao.Location = new System.Drawing.Point(452, 113);
            this.lbl_Campeao.Name = "lbl_Campeao";
            this.lbl_Campeao.Size = new System.Drawing.Size(101, 25);
            this.lbl_Campeao.TabIndex = 12;
            this.lbl_Campeao.Text = "Campeão";
            // 
            // txt_Time06
            // 
            this.txt_Time06.Enabled = false;
            this.txt_Time06.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time06.Location = new System.Drawing.Point(321, 128);
            this.txt_Time06.Name = "txt_Time06";
            this.txt_Time06.Size = new System.Drawing.Size(34, 26);
            this.txt_Time06.TabIndex = 11;
            // 
            // txt_Time05
            // 
            this.txt_Time05.Enabled = false;
            this.txt_Time05.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time05.Location = new System.Drawing.Point(321, 92);
            this.txt_Time05.Name = "txt_Time05";
            this.txt_Time05.Size = new System.Drawing.Size(34, 26);
            this.txt_Time05.TabIndex = 10;
            // 
            // lbl_Time06
            // 
            this.lbl_Time06.AutoSize = true;
            this.lbl_Time06.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time06.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time06.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time06.Location = new System.Drawing.Point(240, 134);
            this.lbl_Time06.Name = "lbl_Time06";
            this.lbl_Time06.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time06.TabIndex = 9;
            this.lbl_Time06.Text = "Time 006";
            // 
            // lbl_Time05
            // 
            this.lbl_Time05.AutoSize = true;
            this.lbl_Time05.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time05.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time05.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time05.Location = new System.Drawing.Point(240, 95);
            this.lbl_Time05.Name = "lbl_Time05";
            this.lbl_Time05.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time05.TabIndex = 8;
            this.lbl_Time05.Text = "Time 005";
            // 
            // txt_Time04
            // 
            this.txt_Time04.Enabled = false;
            this.txt_Time04.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time04.Location = new System.Drawing.Point(105, 197);
            this.txt_Time04.Name = "txt_Time04";
            this.txt_Time04.Size = new System.Drawing.Size(34, 26);
            this.txt_Time04.TabIndex = 7;
            // 
            // txt_Time03
            // 
            this.txt_Time03.Enabled = false;
            this.txt_Time03.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time03.Location = new System.Drawing.Point(105, 161);
            this.txt_Time03.Name = "txt_Time03";
            this.txt_Time03.Size = new System.Drawing.Size(34, 26);
            this.txt_Time03.TabIndex = 6;
            // 
            // txt_Time02
            // 
            this.txt_Time02.Enabled = false;
            this.txt_Time02.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time02.Location = new System.Drawing.Point(105, 66);
            this.txt_Time02.Name = "txt_Time02";
            this.txt_Time02.Size = new System.Drawing.Size(34, 26);
            this.txt_Time02.TabIndex = 5;
            // 
            // txt_Time01
            // 
            this.txt_Time01.Enabled = false;
            this.txt_Time01.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Time01.Location = new System.Drawing.Point(105, 30);
            this.txt_Time01.Name = "txt_Time01";
            this.txt_Time01.Size = new System.Drawing.Size(34, 26);
            this.txt_Time01.TabIndex = 4;
            // 
            // lbl_Time04
            // 
            this.lbl_Time04.AutoSize = true;
            this.lbl_Time04.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time04.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time04.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time04.Location = new System.Drawing.Point(24, 200);
            this.lbl_Time04.Name = "lbl_Time04";
            this.lbl_Time04.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time04.TabIndex = 3;
            this.lbl_Time04.Text = "Time 004";
            // 
            // lbl_Time03
            // 
            this.lbl_Time03.AutoSize = true;
            this.lbl_Time03.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time03.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time03.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time03.Location = new System.Drawing.Point(24, 161);
            this.lbl_Time03.Name = "lbl_Time03";
            this.lbl_Time03.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time03.TabIndex = 2;
            this.lbl_Time03.Text = "Time 003";
            // 
            // lbl_Time02
            // 
            this.lbl_Time02.AutoSize = true;
            this.lbl_Time02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time02.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time02.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time02.Location = new System.Drawing.Point(24, 72);
            this.lbl_Time02.Name = "lbl_Time02";
            this.lbl_Time02.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time02.TabIndex = 1;
            this.lbl_Time02.Text = "Time 002";
            // 
            // lbl_Time01
            // 
            this.lbl_Time01.AutoSize = true;
            this.lbl_Time01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Time01.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_Time01.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time01.Location = new System.Drawing.Point(24, 33);
            this.lbl_Time01.Name = "lbl_Time01";
            this.lbl_Time01.Size = new System.Drawing.Size(75, 20);
            this.lbl_Time01.TabIndex = 0;
            this.lbl_Time01.Text = "Time 001";
            // 
            // frm_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pnl_Atualiza);
            this.Controls.Add(this.pnl_Relatorio);
            this.Name = "frm_Menu";
            this.Text = "Campeonato Paulista 2019";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnl_Atualiza.ResumeLayout(false);
            this.pnl_Atualiza.PerformLayout();
            this.pnl_Relatorio.ResumeLayout(false);
            this.pnl_Relatorio.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem atualizaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatorioToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_Atualiza;
        private System.Windows.Forms.Button btn_Encerra;
        private System.Windows.Forms.Button btn_Proximo;
        private System.Windows.Forms.Button btn_Atualiza;
        private System.Windows.Forms.Label lbl_TimeB;
        private System.Windows.Forms.TextBox txt_TimeB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_TimeA;
        private System.Windows.Forms.Label lbl_TimeA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_Relatorio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_Campeao;
        private System.Windows.Forms.TextBox txt_Time06;
        private System.Windows.Forms.TextBox txt_Time05;
        private System.Windows.Forms.Label lbl_Time06;
        private System.Windows.Forms.Label lbl_Time05;
        private System.Windows.Forms.TextBox txt_Time04;
        private System.Windows.Forms.TextBox txt_Time03;
        private System.Windows.Forms.TextBox txt_Time02;
        private System.Windows.Forms.TextBox txt_Time01;
        private System.Windows.Forms.Label lbl_Time04;
        private System.Windows.Forms.Label lbl_Time03;
        private System.Windows.Forms.Label lbl_Time02;
        private System.Windows.Forms.Label lbl_Time01;
    }
}

