﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Campeonato
{

public partial class frm_Menu : Form
    {
        public frm_Menu()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ExibirDados();
        }
        private void ExibirDados()
        {

        int[] int_Times = new int[4];
        string[] str_Nome = new string[4];
        int[] int_Resul_A = new int[3];
        int[] int_Resul_B = new int[3];
        int[] int_Time_A = new int[3];
        int[] int_Time_B = new int[3];
        int[] int_Venc = new int[3];
        int int_Jogos = 0;
        string str_Campeao = "";
        int int_Qtde = 0;
        int ix1 = 0;

        // definir a string de conexão
        string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

                for (ix1 = 0; ix1 <= int_Qtde; ix1++)
                {
                    if (ix1 <= 2)
                    {
                        DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                        {
                            int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                            int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                            int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                            int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                        }

                        if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                        {
                            int_Venc[ix1] = int_Time_A[ix1];
                        }
                        else
                        {
                            int_Venc[ix1] = int_Time_B[ix1];
                        }
                    }
                }

            oDA.Dispose();
            oDs.Dispose();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            oCn.Close();

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            int_Jogos = int_Jogos + 1;

            if (int_Jogos >= 3)
            {
                int_Jogos = 3;
            }

            int_Qtde = int_Jogos - 1;

            this.label1.Text = "Jogo 00" + int_Jogos.ToString();
            this.lbl_TimeA.Text = str_Nome[int_Time_A[int_Qtde]];
            this.lbl_TimeB.Text = str_Nome[int_Time_B[int_Qtde]];
            this.txt_TimeA.Text = int_Resul_A[int_Qtde].ToString();
            this.txt_TimeB.Text = int_Resul_B[int_Qtde].ToString();

        }
        private void AtualizaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AtualizaçãoToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            pnl_Atualiza.Visible=true;
            pnl_Relatorio.Visible=false;

            int[] int_Times = new int[4];
            string[] str_Nome = new string[4];
            int[] int_Resul_A = new int[3];
            int[] int_Resul_B = new int[3];
            int[] int_Time_A = new int[3];
            int[] int_Time_B = new int[3];
            int[] int_Venc = new int[3];
            int int_jogos = 0;
            string str_Campeao = "";
            int int_Qtde = 0;
            int ix1 = 0;

            int_jogos = Convert.ToInt32(this.label1.Text.Substring(this.label1.Text.Length - 1));

            // definir a string de conexão
            string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                if (ix1 <= 2)
                {
                    DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                    {
                        int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                        int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                        int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                        int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                    }

                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            oDA.Dispose();
            oDs.Dispose();
            oCn.Close();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["Id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            this.lbl_Time01.Text = str_Nome[int_Time_A[0]];
            this.lbl_Time02.Text = str_Nome[int_Time_B[0]];
            this.lbl_Time03.Text = str_Nome[int_Time_A[1]];
            this.lbl_Time04.Text = str_Nome[int_Time_B[1]];
            this.lbl_Time05.Text = str_Nome[int_Time_A[2]];
            this.lbl_Time06.Text = str_Nome[int_Time_B[2]];

            this.txt_Time01.Text = int_Resul_A[0].ToString();
            this.txt_Time02.Text = int_Resul_B[0].ToString();
            this.txt_Time03.Text = int_Resul_A[1].ToString();
            this.txt_Time04.Text = int_Resul_B[1].ToString();
            this.txt_Time05.Text = int_Resul_A[2].ToString();
            this.txt_Time06.Text = int_Resul_B[2].ToString();

            this.lbl_Campeao.Text = str_Nome[int_Venc[2]];

            int_Qtde = int_jogos - 1;

            this.label1.Text = "Jogo 00" + int_jogos.ToString();
            this.lbl_TimeA.Text = str_Nome[int_Time_A[int_Qtde]];
            this.lbl_TimeB.Text = str_Nome[int_Time_B[int_Qtde]];
            this.txt_TimeA.Text = int_Resul_A[int_Qtde].ToString();
            this.txt_TimeB.Text = int_Resul_B[int_Qtde].ToString();

            ExibirDados();
        }

private void RelatorioToolStripMenuItem_Click(object sender, EventArgs e)
{
            pnl_Atualiza.Visible = false;
            pnl_Relatorio.Visible = true;

            int[] int_Times = new int[4];
            string[] str_Nome = new string[4];
            int[] int_Resul_A = new int[3];
            int[] int_Resul_B = new int[3];
            int[] int_Time_A = new int[3];
            int[] int_Time_B = new int[3];
            int[] int_Venc = new int[3];
            int int_Jogos = 0;
            string str_Campeao = "";
            int int_Qtde = 0;
            int ix1 = 0;

            // definir a string de conexão
            string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                if (ix1 <= 3)
                {
                    DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                    {
                        int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                        int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                        int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                        int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                    }

                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            oDA.Dispose();
            oDs.Dispose();
            oCn.Close();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["Id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            this.lbl_Time01.Text = str_Nome[int_Time_A[0]];
            this.lbl_Time02.Text = str_Nome[int_Time_B[0]];
            this.lbl_Time03.Text = str_Nome[int_Time_A[1]];
            this.lbl_Time04.Text = str_Nome[int_Time_B[1]];
            this.lbl_Time05.Text = str_Nome[int_Time_A[2]];
            this.lbl_Time06.Text = str_Nome[int_Time_B[2]];

            this.txt_Time01.Text = int_Resul_A[0].ToString();
            this.txt_Time02.Text = int_Resul_B[0].ToString();
            this.txt_Time03.Text = int_Resul_A[1].ToString();
            this.txt_Time04.Text = int_Resul_B[1].ToString();
            this.txt_Time05.Text = int_Resul_A[2].ToString();
            this.txt_Time06.Text = int_Resul_B[2].ToString();

            this.lbl_Campeao.Text = str_Nome[int_Venc[2]];

            ExibirDados();
}

        private void Btn_Proximo_Click(object sender, EventArgs e)
        {
            int[] int_Times = new int[4];
            string[] str_Nome = new string[4];
            int[] int_Resul_A = new int[3];
            int[] int_Resul_B = new int[3];
            int[] int_Time_A = new int[3];
            int[] int_Time_B = new int[3];
            int[] int_Venc = new int[3];
            string str_Campeao = "";
            int int_Qtde = 0;
            int ix1 = 0;
            int int_jogos = 0;

            // definir a string de conexão
            string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                if (ix1 <= 3)
                {
                    DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                    {
                        int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                        int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                        int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                        int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                    }

                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            oDA.Dispose();
            oDs.Dispose();
            oCn.Close();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["Id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            int_jogos = Convert.ToInt32(this.label1.Text.Substring(this.label1.Text.Length - 1));
            int_jogos = int_jogos + 1;

            if (int_jogos >= 3)
            {
                int_jogos = 3;
            }

            int_Qtde = int_jogos - 1;

            this.label1.Text = "Jogo 00" + int_jogos.ToString();
            this.lbl_TimeA.Text = str_Nome[int_Time_A[int_Qtde]];
            this.lbl_TimeB.Text = str_Nome[int_Time_B[int_Qtde]];
            this.txt_TimeA.Text = int_Resul_A[int_Qtde].ToString();
            this.txt_TimeB.Text = int_Resul_B[int_Qtde].ToString();

        }

        private void Btn_Atualiza_Click(object sender, EventArgs e)
        {
            int[] int_Times = new int[4];
            string[] str_Nome = new string[4];
            int[] int_Resul_A = new int[3];
            int[] int_Resul_B = new int[3];
            int[] int_Time_A = new int[3];
            int[] int_Time_B = new int[3];
            int[] int_Venc = new int[3];
            int int_Jogos = 0;
            string str_Campeao = "";
            int int_Qtde = 0;
            int ix1 = 0;

            // definir a string de conexão
            string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                if (ix1 <= 3)
                {
                    DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                    {
                        int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                        int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                        int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                        int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                    }

                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            oDA.Dispose();
            oDs.Dispose();
            oCn.Close();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["Id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            int_Resul_A[int_Qtde - 1] = Convert.ToInt32(this.txt_TimeA.Text.ToString()) - 1;
            int_Resul_B[int_Qtde - 1] = Convert.ToInt32(this.txt_TimeB.Text.ToString()) - 1;

            ix1 = 0;

            for (ix1 = 0; ix1 <= 2; ix1++)
            {
                if (ix1 <= 2)
                {
                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            //definir a string SQL
            sSQL = "Select * from Jogos Where id_Jogo = " + int_Jogos.ToString();

            oCn.Close();

            //criar o objeto connection
            oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA3 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs3 = new DataSet();

            //criar o data adapter e executar a consulta 
            oDA3 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            oDs3 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA3.Fill(oDs3, "Jogos");

            DataRow oDR3 = oDs3.Tables["Jogos"].Rows[0];

//            oDR3("res_Time_A"; int_Resul_A[int_Qtde - 1].ToString());
//            oDR3("res_Time_B"; int_Resul_B[int_Qtde - 1].ToString());

//            oDA3.Update;

            oDA3.Dispose();
            oDs3.Dispose();
            oCn.Dispose();

            if (int_Jogos >= 3)
            {
                int_Jogos = 3;
            }

            int_Qtde = int_Jogos - 1;

            this.label1.Text = "Jogo 00" + int_Jogos.ToString();
            this.lbl_TimeA.Text = str_Nome[int_Time_A[int_Qtde]];
            this.lbl_TimeB.Text = str_Nome[int_Time_B[int_Qtde]];
            this.txt_TimeA.Text = int_Resul_A[int_Qtde].ToString();
            this.txt_TimeB.Text = int_Resul_B[int_Qtde].ToString();

        }

        private void Btn_Encerra_Click(object sender, EventArgs e)
        {
            pnl_Atualiza.Visible = false;
            pnl_Relatorio.Visible = true;

            int[] int_Times = new int[4];
            string[] str_Nome = new string[4];
            int[] int_Resul_A = new int[3];
            int[] int_Resul_B = new int[3];
            int[] int_Time_A = new int[3];
            int[] int_Time_B = new int[3];
            int[] int_Venc = new int[3];
            int int_Jogos = 0;
            string str_Campeao = "";
            int int_Qtde = 0;
            int ix1 = 0;

            // definir a string de conexão
            string sDBstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\Projetos\Torneios.mdb";

            //definir a string SQL
            string sSQL = "SELECT * from Jogos";

            //criar o objeto connection
            OleDbConnection oCn = new OleDbConnection(sDBstr);
            //abrir a conexão
            oCn.Open();
            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA.Fill(oDs, "Jogos");

            int_Qtde = Convert.ToInt32(oDs.Tables["Jogos"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                if (ix1 <= 3)
                {
                    DataRow oDR = oDs.Tables["Jogos"].Rows[ix1];
                    {
                        int_Time_A[ix1] = Convert.ToInt32(oDR["Id_time_A"].ToString()) - 1;
                        int_Resul_A[ix1] = Convert.ToInt32(oDR["res_time_A"].ToString());
                        int_Time_B[ix1] = Convert.ToInt32((oDR["Id_time_B"].ToString())) - 1;
                        int_Resul_B[ix1] = Convert.ToInt32((oDR["res_time_B"].ToString()));
                    }

                    if (int_Resul_A[ix1] >= int_Resul_B[ix1])
                    {
                        int_Venc[ix1] = int_Time_A[ix1];
                    }
                    else
                    {
                        int_Venc[ix1] = int_Time_B[ix1];
                    }
                }
            }

            oDA.Dispose();
            oDs.Dispose();
            oCn.Close();

            //definir a string SQL
            sSQL = "SELECT * from Times";

            //abrir a conexão
            oCn.Open();

            //criar o data adapter e executar a consulta 
            OleDbDataAdapter oDA2 = new OleDbDataAdapter(sSQL, oCn);
            //criar o DataSet
            DataSet oDs2 = new DataSet();

            //Preencher o dataset coom o data adapter
            oDA2.Fill(oDs2, "Times");

            int_Qtde = Convert.ToInt32(oDs2.Tables["Times"].Rows.Count.ToString()) - 1;

            for (ix1 = 0; ix1 <= int_Qtde; ix1++)
            {
                DataRow oDR2 = oDs2.Tables["Times"].Rows[ix1];
                int_Times[ix1] = Convert.ToInt32((oDR2["Id_time"].ToString()));
                str_Nome[ix1] = oDR2["Nome"].ToString();
            }

            // liberar o data adapter , o dataset e a conexao
            oDA2.Dispose();
            oDs2.Dispose();
            oCn.Dispose();

            this.lbl_Time01.Text = str_Nome[int_Time_A[0]];
            this.lbl_Time02.Text = str_Nome[int_Time_B[0]];
            this.lbl_Time03.Text = str_Nome[int_Time_A[1]];
            this.lbl_Time04.Text = str_Nome[int_Time_B[1]];
            this.lbl_Time05.Text = str_Nome[int_Time_A[2]];
            this.lbl_Time06.Text = str_Nome[int_Time_B[2]];

            this.txt_Time01.Text = int_Resul_A[0].ToString();
            this.txt_Time02.Text = int_Resul_B[0].ToString();
            this.txt_Time03.Text = int_Resul_A[1].ToString();
            this.txt_Time04.Text = int_Resul_B[1].ToString();
            this.txt_Time05.Text = int_Resul_A[2].ToString();
            this.txt_Time06.Text = int_Resul_B[2].ToString();

            this.lbl_Campeao.Text = str_Nome[int_Venc[2]];

            ExibirDados();
        }


    }
}
